#include<stdio.h>

void method(int m, int n, int* a);

int main()

{

	int a[10];

	int i, m, n;

	for (i = 0; i < 10; i++)

		scanf("%d", &a[i]);

	scanf("%d%d", &m, &n);

	method(m, n, a);

	for (i = 0; i < 10; i++)

		printf("%d ", a[i]);

	return 0;

}


void method(int m, int n, int* a)

{

	int c[10] = { 0 };

	int j = m + n - 2;

	int* b = c;
	while (j >= m - 1)
	{
		*b = *(a + j);
		b++;
		j--;
	}
	for (j = 1; j < m; j++)
		a++;
	for (j = 0; j < n; j++)

		b--;

	for (j = m; j < m + n; j++)

	{

		*a = *b;

		a++;

		b++;

	}

}