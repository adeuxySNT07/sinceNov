//StudybarCommentBegin
#include <stdio.h>
#include <string.h>

int main()
{
    char str[80], * pStart, * pEnd;
    int len;

    gets(str);
    len = strlen(str);
    pStart = str;
    pEnd = str + len - 1;
//StudybarCommentEnd



//StudybarCommentBegin
return 0;
}

//StudybarCommentEnd