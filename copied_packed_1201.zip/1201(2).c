#include<stdio.h>
int swap(int* pt1, int* pt2)
{
int temp;
temp = *pt1;
*pt1 = *pt2;
*pt2 = temp;
}

int sort_three(int* p1, int* p2, int* p3) {
	if (*p1 > *p2)
		swap(p1, p2);
	if (*p1 > *p3)
		swap(p1, p3);
	if (*p2 > *p3)
		swap(p2, p3);
}
int main()
{
	int a, b, c; int* p1, * p2, * p3;
	scanf("%d,%d,%d", &a, &b, &c);
	printf("origin:%d,%d,%d\n", a, b, c);
	p1 = &a, p2 = &b, p3 = &c;
	sort_three(p1, p2, p3);
	printf("sort:%d,%d,%d\n", a, b, c);
	return 0;
}
