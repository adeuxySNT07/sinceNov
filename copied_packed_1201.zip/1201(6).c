#include <stdio.h>
char* longest(char* p) {
    char* t, max, n;
    while (*p == ' ') p++;
    for (max = n = 0, t = p; *p; p++)
        if (*p != ' ')
            n++;
        else {
            if (max <= n)
                max = n, t = p - n;
            n = 0;
        }
    return max <= n ? p - n : t;
}
int main(void) {
    char str[1000], * p;
    scanf("%[A-Z a-z]", str);
    printf("word=");
    for (p = longest(str); *p && *p != ' '; printf("%c", *p++));
    printf("\n");
    return 0;
}